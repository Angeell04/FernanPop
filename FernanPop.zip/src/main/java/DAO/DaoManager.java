package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DaoManager {
    private Connection conn;
    private final String URL;
    private final String USER;
    private final String PASS;
    private static DaoManager singleton;


    private DaoManager() {
        this.conn = null;
        this.URL = "jdbc:mysql://localhost:3306/fernanPop?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Europe/Madrid";
        this.USER = "root";
        this.PASS = "root";
    }

    public static DaoManager getSingletonInstance(){

        if(singleton == null) singleton = new DaoManager();
        return singleton;
    }

    public Connection getConn(){
        return conn;
    }

    public void open() throws Exception{
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL,USER,PASS);
        }catch (Exception e) {
            throw  e;
        }
    }

    public void close() throws SQLException{
        try {
            if (this.conn != null) this.conn.close();

        }catch (Exception e) {
            throw e;
        }
    }
}